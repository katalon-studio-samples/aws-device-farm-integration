import org.openqa.selenium.remote.DesiredCapabilities as DesiredCapabilities
import io.appium.java_client.MobileElement as MobileElement
import io.appium.java_client.ios.IOSDriver as IOSDriver

String URL_STRING = 'http://127.0.0.1:4723/wd/hub'

URL url = new URL(URL_STRING)

// driver = new AdroidDriver<MobileElement>(url, new DesiredCapabilities());
DesiredCapabilities capabilities = new DesiredCapabilities()
driver = new IOSDriver<MobileElement>(url, capabilities)

driver.close()