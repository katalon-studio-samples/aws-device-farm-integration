<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Regression Tests</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>f749b22d-d796-48cd-9290-f9a7692d2371</testSuiteGuid>
   <testCaseLink>
      <guid>10b0ccf7-c4a4-40eb-ba7c-c5bdc5247155</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/New Test Case</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>3c3b2a70-30bc-46e7-86a9-5202a525c688</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>48541da7-6c9f-42e4-a4bd-3a0b5f63b02f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/New Test Case (1)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1ab6c7d9-0442-4183-817a-356fd84ddffe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/New Test Case (3)</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
